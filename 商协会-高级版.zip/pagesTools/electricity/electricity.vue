<template>
	<view>
		<!-- 标题栏 -->
		<title-bar title="电费充值"></title-bar>
		<view class="container">
			<!-- 扫码缴费功能区 -->
			<view class="scan-to-pay">
				<view class="meter-info">
					<view>当前余额：{{ meterInfo.balance||0.00 }}元</view>
					<view>电表信息：{{ meterInfo.meter_num||'等待查询' }}</view>
					<view>所属公司：{{ meterInfo.meter_company||'等待查询' }}</view>
					<view>电表位置：{{ meterInfo.meter_place||'等待查询' }}</view>
					<view class="title">
						缴费金额
					</view>
					<view class="jiebox">
						<text>￥</text>
						<input type="digit" value="" placeholder="请输入充值金额" v-model="amount" />
					</view>
				</view>
				<view @click="startScan" class="scan-button">
					<view class="scan-text">立即缴费</view>
				</view>
			</view>
			
			<view class="footer">
				<view class="record" @click="getorder()">缴费记录</view>
				<view class="fenge">|</view>
				<view class="lift" @click="unbinding()">解除绑定</view>
			</view>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				amount: '',
				meterInfo: null,
				electricity: null
			};
		},
		onShow() {
			this.queryBalance()
		},
		onLoad(e) {
			this.electricity = e.electricity
			this.queryBalance()
		},
		methods: {
			getorder() {
				uni.navigateTo({
					url:"/pagesTools/electricity/orderlist?electricity="+this.electricity
				})
			},
			// 获取电表信息
			queryBalance() {
				var that = this
				that.$util.request("mall.balance", {
					electricity: that.electricity
				}).then(res => {
					if (res.code === 1) {
						res.data.balance = (res.data.balance / 100).toFixed(2)
						this.meterInfo = res.data;
					} else {
						uni.showToast({
							title: res.msg,
							icon: 'none'
						});
					}
				}).catch(err => {
					console.error('Error querying balance:', err);
				});
			},
			//解除绑定
			unbinding(){
				var that = this
				uni.showModal({
					confirmText:'确定解除',
					confirmColor:"#E60012",
					content:"确认解除绑定此电表吗？",
					success(res) {
						if(res.confirm){
							that.$util.request("mall.unbinding", {
								electricity: that.electricity
							}).then(res => {
								uni.showToast({
									title: res.msg,
									icon: 'none',
									success() {
										setTimeout(function(){
											uni.navigateBack()
										},2000)
									}
								});
							}).catch(err => {
								console.error('Error querying balance:', err);
							});
						}else{
							console.log("取消解除")
						}
					}
				})
			},
			startScan() {
				var that = this
				if (that.amount == '' || that.amount == 0) {
					uni.showToast({
						title: "请输入充值金额",
						icon: 'none'
					})
					return false;
				}

				// 这里可以处理扫描后的逻辑，比如显示电表信息和输入充值金额等
				that.$util.request("mall.electricity", {
					amount: that.amount,
					electricity: this.electricity
				}).then(res => {
					if (res.code === 200) {
						uni.requestPayment({
							provider: 'wxpay', // 看需求，每个端都有各自的值，eg: 'alipay'
							timeStamp: res.data.timeStamp, // 当前时间戳（从1970年1月1日至今的秒数）
							nonceStr: res.data.nonceStr, // 随机字符串 - 也可以后端返回
							package: res.data.package, // 后端接口返回
							paySign: res.data.paySign, // 后端返回
							signType: 'MD5', // 签名的算法，默认值 ’MD5‘
							success: (result) => {
								// result成功返回内容 errMsg: "requestPayment:ok"
								if (result.errMsg == "requestPayment:ok") {
									uni.showToast({
										title: "充值成功",
										icon: 'none',
										duration: 2000,
										success() {
											setTimeout(() => {
												uni.navigateBack();
											}, 2000);
										}
									})
								}

								// 支付成功跳转结果页
							},
							fail: (err) => {
								console.log('fail', err)
								uni.showToast({
									title: '订单已生成，支付失败',
									icon: 'none',
									duration: 2000
								})
							}
						})

					} else {
						uni.showToast({
							title: "订单生成失败",
							icon: 'none',
							duration: 2000
						})
					}
				})

			}
		}
	};
</script>

<style>
	.container {
		background-color: #f5f5f5;
		padding: 20px;
	}

	.card {
		background-color: #fff;
		border-radius: 10px;
		box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
		padding: 20px;
		margin-bottom: 20px;
	}

	.content {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.label {
		font-size: 16px;
		color: #777;
	}

	.amount {
		font-size: 24px;
		font-weight: bold;
		color: #333;
	}

	.more-button {
		background-color: #007bff;
		color: #fff;
		border: none;
		padding: 10px 20px;
		border-radius: 5px;
		cursor: pointer;
		transition: background-color 0.3s;
	}

	.more-button:hover {
		background-color: #0056b3;
	}

	.scan-to-pay {
		margin-bottom: 40rpx;
	}

	.scan-button {
		background-color: #28a745;
		color: #fff;
		border: none;
		padding: 10px 20px;
		border-radius: 5px;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		transition: background-color 0.3s;
	}

	.scan-button:hover {
		background-color: #218838;
	}

	.scan-icon {
		width: 24px;
		height: 24px;
		margin-right: 10px;
	}

	.scan-text {
		font-size: 16px;
		font-weight: bold;
	}

	.section-title {
		font-size: 18px;
		font-weight: bold;
		color: #333;
		margin-bottom: 10px;
	}

	.title {
		font-size: 32rpx;
		font-weight: bold;
		margin-top: 20rpx;
	}

	.record-item {
		font-size: 14px;
		color: #555;
		margin-bottom: 10px;
	}

	.meter-info {
		background-color: #f9f9f9;
		width: 650rpx;
		padding: 30rpx;
		background: #fff;
		font-size: 30rpx;
		border-top: 1rpx solid #f1f1f1;
		line-height: 60rpx;
		margin-bottom: 100rpx;
	}

	.jiebox {
		display: flex;
		height: 80rpx;
		line-height: 80rpx;
		border-bottom: 1rpx solid #bfbfbf;

	}

	.jiebox>text {
		font-weight: 900;

	}

	.jiebox>input {
		height: 80rpx;
		line-height: 80rpx;
		padding-left: 10rpx;
	}
	.footer{
		width: 300rpx;
		display: flex;
		justify-content: space-evenly;
		font-size: 24rpx;
		color: #0037ff;
		margin: 0 auto;
		position: fixed;
		left: 0;
		right: 0;
		bottom: 100rpx;
	}
</style>