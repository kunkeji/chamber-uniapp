<template>
	<view>
		<title-bar title="电费充值"></title-bar>

		<view class="container">
			<view class="electricityBox">
				<view class="inputbox">
					<input type="number" v-model="electricity" value="" placeholder="请输入12位电表号" @input="checkLength" />
				</view>
				<view class="saoma">
					<image src="/static/scan.png" @click="scanCode"></image>
				</view>
			</view>
			<view class="electricityBox">
				<view class="inputbox">
					<input type="text" v-model="notes" value="" placeholder="填写备注信息"/>
				</view>
			</view>
			<!-- <input type="text" v-model="electricity" placeholder="请输入电表号" @input="checkLength" /> -->
			
			<view class="meter-info">
				<view>当前余额：{{ meterInfo.balance||0.00 }}元</view>
				<view>电表信息：{{ meterInfo.meter_num||'等待查询' }}</view>
				<view>所属公司：{{ meterInfo.meter_company||'等待查询' }}</view>
				<view>电表位置：{{ meterInfo.meter_place||'等待查询' }}</view>
			</view>
			<view class="submit-btn" v-if="meterInfo" @click="submit">确定绑定</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				electricity: '',
				notes:'',
				meterInfo: null
			};
		},
		methods: {
			scanCode() {
				uni.scanCode({
					success: (res) => {
						this.electricity = res.result;
						this.checkLength();
					},
					fail: (err) => {
						console.error('Scan failed:', err);
					}
				});
			},
			checkLength() {
				if (this.electricity.length === 12) {
					this.queryBalance();
				}
			},
			queryBalance() {
				var that = this
				that.$util.request("mall.balance", {
					electricity: this.electricity
				}).then(res => {
					if (res.code === 1) {
						res.data.balance  =  (res.data.balance/100).toFixed(2)
						this.meterInfo = res.data;
					} else {
						uni.showToast({
							title: res.msg,
							icon: 'none'
						});
					}
				}).catch(err => {
					console.error('Error querying balance:', err);
				});
			},
			submit() {
				var that = this
				if (!this.meterInfo) {
					uni.showToast({
						title: '请先查询电表信息',
						icon: 'none'
					});
					return;
				}
				if(!that.notes){
					uni.showToast({
						title: '请填写备注',
						icon: 'none'
					});
					return;
				}
				// 这里可以添加提交绑定的接口调用
				that.$util.request('mall.binding',{
					id:that.meterInfo.id,
					meter_num:that.meterInfo.meter_num,
					notes:that.notes
				}).then(res=>{
					uni.showToast({
						icon:"none",
						title:res.msg,
						success() {
							setTimeout(() => {
								uni.navigateBack();
							}, 2000);
							
						}
					})
					
				})
				
				
			}
		}
	};
</script>

<style>
	.container {
		padding: 20px;
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	.electricityBox{
		width: 650rpx;
		    background: #fff;
		    padding: 30rpx;
		    display: flex;
		    justify-content: space-between;
	}
	.inputbox{
		height: 60rpx;
		    line-height: 60rpx;
	}
	.inputbox>input{
		width: 100%;
		height: 100%;
		line-height: 60rpx;
		border: none;
	}
	.saoma{
		width: 50rpx;
		height: 50rpx;
	}

	/* input {
		width: 80%;
		height: 40px;
		padding: 10px;
		margin-bottom: 20px;
		border: 1px solid #ccc;
		border-radius: 5px;
	} */

	/* image {
		width: 40px;
		height: 40px;
	} */

	.meter-info {
		background-color: #f9f9f9;
		margin-bottom: 20px;
		width: 650rpx;
		    padding: 30rpx;
		    background: #fff;
		    font-size: 30rpx;
		    border-top: 1rpx solid #f1f1f1;
		    line-height: 60rpx;
	}

	.submit-btn {
		margin-top: 100rpx;
		width: 80%;
		background-color: #1aad19;
		color: white;
		text-align: center;
		line-height: 44px;
		border-radius: 5px;
	}
</style>