<template>
	<view>
		<title-bar title="电费充值"></title-bar>

		<view class="container">
			<block v-if="list.length > 0">
				<view class="list-item" v-for="(item, index) in list" :key="index" @click="goToDetail(item)">
					<view class="itemicon">
						<image src="../../static/mine/member_7.png" mode="aspectFill"></image>
					</view>
					<view class="content">
						<view class="electricity">电表号|{{item.electricity}}</view>
						<view class="notes">{{ item.notes }}</view>
						<view class="tishi">轻触缴费查余额</view>
					</view>
					<view class="right">
						<image src="../../static/right.png" mode="aspectFill"></image>
					</view>

				</view>
			</block>
			<view class="list-item newlist" @click="navigateToAdd()">
				<view class="itemicon">
					<image src="../../static/mine/member_7.png" mode="aspectFill"></image>
				</view>
				<view class="contentb">
					<view>电费</view>
				</view>
				<view class="bottomright">
					<text>去添加</text>
					<view>
						<image src="../../static/right.png" mode="aspectFill"></image>
					</view>
				</view>
			</view>

		</view>
		<view class="footer">
			<view class="record" @click="getorder()">缴费记录</view>
<!-- 			<view class="fenge">|</view>
			<view class="lift" @click="unbinding()">解除绑定</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: []
			};
		},
		onShow() {
			this.fetchList();
		},
		methods: {
			getorder() {
				uni.navigateTo({
					url:"/pagesTools/electricity/orderlist"
				})
			},
			fetchList() {
				var that = this
				that.$util.request("mall.get_binding").then(res => {
					if (res.code === 1) {
						this.list = res.data;
					} else {
						uni.showToast({
							title: res.msg,
							icon: 'none'
						});
					}
				}).catch(err => {
					console.error('Error fetching data:', err);
				});
			},
			goToDetail(item) {
				// 跳转到充值详情页
				uni.navigateTo({
					url: `/pagesTools/electricity/electricity?electricity=${item.electricity}`
				});
			},
			navigateToAdd() {
				// 跳转到添加页面
				uni.navigateTo({
					url: '/pagesTools/electricity/add'
				});
			}
		}
	};
</script>

<style>
	image {
		width: 100%;
		height: 100%;
	}

	.container {
		padding: 40rpx;
	}

	.list-item {
		background: #fff;
		padding: 30rpx 15rpx;
		border-radius: 10rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.newlist {
		margin-top: 30rpx;
		filter: grayscale(70%);
		color: #999;
	}

	.empty-tip {
		text-align: center;
		color: #999;
		margin-top: 40rpx;
	}

	.add-more {
		width: 100%;
		background-color: #1aad19;
		color: white;
		text-align: center;
		line-height: 88rpx;
		margin-top: 40rpx;
		border-radius: 10rpx;
	}

	.itemicon {
		width: 80rpx;
		height: 80rpx;
	}

	.content {
		width: 460rpx;
		font-size: 28rpx;
	}

	.contentb {
		width: 360rpx;
		font-size: 28rpx;
		height: 60rpx;
		line-height: 60rpx;
		margin-left: 30rpx;
	}

	.tishi {
		font-weight: bold;
	}

	.right {
		width: 60rpx;
		height: 60rpx;
	}

	.bottomright {
		width: 200rpx;
		height: 60rpx;
		display: flex;
		font-size: 30rpx;
		line-height: 60rpx;
	}

	.bottomright>view {
		width: 60rpx;
		height: 60rpx;
	}
	.footer{
		width: 300rpx;
		display: flex;
		justify-content: space-evenly;
		font-size: 24rpx;
		color: #0037ff;
		margin: 120rpx auto;
		/* position: fixed;
		left: 0;
		right: 0;
		bottom: 100rpx; */
	}
</style>