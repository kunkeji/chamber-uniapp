<template>
	<view>
		<!-- 标题栏 -->
		<title-bar title="电费充值"></title-bar>

		<view class="container">
			<scroll-view scroll-y @scrolltolower="loadMore" :style="{height: windowHeight + 'px'}">
				<block v-for="(monthGroup, index) in groupedData" :key="index">
					<view class="month-title">
						<view>{{ monthGroup.month}}</view>
						<view>{{ monthGroup.totalAmount }} 元</view>
					</view>
					<view class="list-item" v-for="item in monthGroup.items" :key="item.id">
						<view class="list-item-info">
							<view>订单号: {{ item.order_number }}</view>
							<view>{{ item.electricity }}|{{ item.meter_place }}</view>
							<!-- <view>{{ item.status === '1' ? '成功' : '失败' }}</view> -->
							<view>{{ formatTime(item.createtime) }}</view>
						</view>
						<view class="money">￥{{ item.total_amount }} 元</view>
					</view>
				</block>
				<view v-if="loading" class="loading">加载中...</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				electricity: null,
				offset: 0,
				pagesize: 10,
				loading: false,
				data: [],
				windowHeight: 0
			};
		},
		computed: {
			// 按月份分组数据
			groupedData() {
				const grouped = {};
				this.data.forEach(item => {
					const month = this.formatMonth(item.createtime);
					if (!grouped[month]) {
						grouped[month] = {
							month: month,
							totalAmount: 0,
							items: []
						};
					}
					grouped[month].items.push(item);
					grouped[month].totalAmount += parseFloat(item.total_amount);
					grouped[month].totalAmount = parseFloat(grouped[month].totalAmount.toFixed(2));
				});
				return Object.values(grouped);
			}
		},
		methods: {
			// 格式化时间戳为日期格式
			formatTime(timestamp) {
			    const date = new Date(timestamp * 1000);
			    const year = date.getFullYear();
			    const month = (date.getMonth() + 1).toString().padStart(2, '0');
			    const day = date.getDate().toString().padStart(2, '0');
			    const hours = date.getHours().toString().padStart(2, '0');
			    const minutes = date.getMinutes().toString().padStart(2, '0');
			    const seconds = date.getSeconds().toString().padStart(2, '0');
			
			    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
			  },
			// 格式化时间戳为月份格式
			formatMonth(timestamp) {
				const date = new Date(timestamp * 1000);
				return `${date.getFullYear()}-${date.getMonth()+1}`;
			},
			// 加载更多数据
			loadMore() {
				if (this.loading) return;
				this.loading = true;
				this.loadBindingList();
			},
			// 加载绑定列表
			async loadBindingList() {
				try {
					const res = await this.$util.request("mall.get_order", {
						electricity: this.electricity?this.electricity:'',
						offset: this.offset,
						pagesize: this.pagesize
					});
					if (res.code === 1) {
						this.data = [...this.data, ...res.data];
						this.offset += this.pagesize;
					}
				} catch (error) {
					console.error('请求失败', error);
				} finally {
					this.loading = false;
				}
			}
		},
		onLoad(options) {
			if (options.electricity) {
				this.electricity = options.electricity;
			}
			// 初始化加载数据
			this.loadBindingList();
			// 获取屏幕高度以设置滚动视图的高度
			uni.getSystemInfo({
				success: (res) => {
					this.windowHeight = res.windowHeight;
				}
			});
		}
	};
</script>

<style scoped>
	.container{
		margin-bottom: 100rpx;
	}
	.list-item {
		padding: 25rpx;
		background-color: #ffffff;
		border-radius: 10rpx;
		display: flex;
		justify-content: space-between;
		border-bottom: 1rpx solid #eaeaea;
		font-size: 30rpx;
		    line-height: 44rpx;
	}
	.list-item:last-child{
		border-bottom: none;
	}

	.month-title {
		padding: 25rpx 0;
		font-size: 30rpx;
		color: #333;
		font-weight: bold;
		display: flex;
		    justify-content: space-between;
		    width: 700rpx;
		    margin: 0 auto;
	}
	.money{
		font-size: 36rpx;
		    font-weight: bold;
	}

	.loading {
		text-align: center;
		padding: 25rpx;
		color: #999;
	}
</style>