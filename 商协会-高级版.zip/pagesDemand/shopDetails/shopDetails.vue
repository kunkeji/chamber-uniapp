<template>
	<view>
		<title-bar :title="navigationBarTitle"></title-bar>
		<view class="container">
			<view class="info-card">
				<view class="store-image" @click="chooseImage">
					<image :src="shopImage" class="store-image-preview" mode="aspectFill"></image>
					<text v-if="!shopImage" class="upload-text">点击上传图片</text>
				</view>

				<view class="store-name">店铺名称: <input v-model="shop.title" placeholder="请输入店铺名称" /></view>

				<view class="store-slogan">店铺标语: <input v-model="shop.slogan" placeholder="请输入店铺标语" /></view>
				<view class="store-delivery">
					是否支持配送:
					<switch :checked="shop.delivery == 1" @change="toggleDelivery" />
				</view>
				<view class="store-status">
					是否营业:
					<switch :checked="shop.status == 1" @change="toggleStatus" />
				</view>
				<view class="store-produce">产出时间: <input v-model="shop.produce" type="number" placeholder="请输入产出时间" />
				</view>
			</view>
			<view class="action-buttons">
				<button @click="updateShop">保存修改</button>
			</view>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				navigationBarTitle: "店铺管理",
				shop: {
					id: null,
					title: "",
					shop_image: "",
					delivery: 0,
					slogan: "",
					status: 0,
					produce: 0,
				},
				shopId: null,
				selectImages: [],
			};
		},
		computed: {
			shopImage() {
				if (this.shop.shop_image) {
					return getApp().globalData.adminPath + this.shop.shop_image;
				}
				return "";
			},
		},
		methods: {
			getShopInfo() {
				this.$util.request("main.Shop.getShopByShopId", {
					shop_id: this.shopId
				}).then(res => {
					if (res.code === 1) {
						this.shop = {
							...res.data,
							delivery: parseInt(res.data.delivery),
							status: parseInt(res.data.status)
						};
					} else {
						uni.showToast({
							title: '获取店铺信息失败',
							icon: 'none',
							duration: 2000,
						});
					}
				}).catch(error => {
					console.error('请求失败', error);
					uni.showToast({
						title: '请求失败',
						icon: 'none',
						duration: 2000,
					});
				});
			},
			chooseImage() {
				uni.chooseImage({
					count: 1,
					success: (res) => {
						this.selectImages = res.tempFilePaths;
						this.shop.shop_image = res.tempFilePaths[0];
						this.$util.uploadFile(res.tempFilePaths[0]).then(res => {
							this.shop.shop_image = res.data['url']; // 更新图片路径
						}).catch(error => {
							console.error('上传图片失败', error);
							uni.showToast({
								title: '上传图片失败',
								icon: 'none',
								duration: 2000,
							});
						});
					},
				});
			},
			toggleDelivery(value) {
				this.shop.delivery = value.detail.value ? 1 : 0;
			},
			toggleStatus(value) {
				this.shop.status = value.detail.value ? 1 : 0;
			},
			updateShop() {
				this.sendUpdateRequest();
			},
			sendUpdateRequest() {
				const params = {
					id: this.shop.id,
					title: this.shop.title,
					shop_image: this.shop.shop_image,
					delivery: this.shop.delivery.toString(),
					slogan: this.shop.slogan,
					status: this.shop.status.toString(),
					produce: this.shop.produce,
				};

				this.$util.request("main.Shop.updateShopById", params).then(res => {
					if (res.code === 1) {
						uni.showToast({
							title: '更新成功',
							icon: 'success',
							duration: 2000,
						});
						uni.navigateBack();
					} else {
						uni.showToast({
							title: '更新失败',
							icon: 'none',
							duration: 2000,
						});
					}
				}).catch(error => {
					console.error('请求失败', error);
					uni.showToast({
						title: '请求失败',
						icon: 'none',
						duration: 2000,
					});
				});
			},
		},
		onLoad(options) {
			this.shopId = options.id;
			this.getShopInfo();
		},
	};
</script>


<style scoped>
	.container {
		padding: 30rpx;
		background-color: #FAFAFA;
	}

	.info-card {
		width: 690rpx;
		background-color: #FFFFFF;
		border-radius: 15rpx;
		padding: 30rpx;
		margin: 0 auto;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.store-name,
	.store-slogan,
	.store-delivery,
	.store-status,
	.store-produce {
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 20rpx;
	}

	.store-name input,
	.store-slogan input,
	.store-produce input {
		width: 100%;
		padding: 10rpx;
		border: 1rpx solid #E0E0E0;
		border-radius: 10rpx;
		font-size: 24rpx;
		margin-top: 10rpx;
	}

	.store-image {
		display: flex;
		align-items: center;
		justify-content: center;
		margin-bottom: 20rpx;
		position: relative;
		cursor: pointer;
	}

	.store-image-preview {
		width: 200rpx;
		height: 200rpx;
		border-radius: 10rpx;
	}

	.upload-text {
		font-size: 24rpx;
		color: #999999;
	}

	.store-image::after {
		content: '';
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		border: 2rpx dashed #E0E0E0;
		border-radius: 10rpx;
		opacity: 0.5;
		pointer-events: none;
	}

	.action-buttons {
		display: flex;
		justify-content: center;
		margin-top: 30rpx;
	}

	.action-buttons button {
		background-color: #00BFFF;
		color: #FFFFFF;
		border: none;
		padding: 15rpx 30rpx;
		border-radius: 10rpx;
		cursor: pointer;
		transition: background-color 0.3s;
		font-size: 32rpx;
	}

	.action-buttons button:hover {
		background-color: #00A2E8;
	}
</style>