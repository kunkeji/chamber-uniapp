<template>
	<view>
		<title-bar :title="navigationBarTitle"></title-bar>

		<view class="container">
			<view class="goods-list">
				<view class="goods-item" v-for="item in goodsList" :key="item.id">
					<image class="goods-image" :src="shopImage(item.goods_image)" mode="aspectFill"></image>
					<view class="goods-info">
						<text class="goods-name">{{ item.goods_name }}</text>
						<text class="goods-norms">{{ item.norms }}</text>
						<text class="goods-slogan">{{ item.slogan }}</text>
						<text class="goods-price">￥{{ item.price }}</text>
						<text class="goods-status">{{ getStatusText(item.status) }}</text>
					</view>
					<view class="goods-actions">
						<view class="action-btn" @click="editGoods(item)">修改</view>
						<view class="action-btn deletebut" @click="deleteGoods(item.id)">删除</view>
					</view>
				</view>
			</view>
			<view class="add-btn" @click="addGoods">添加菜品</view>

			<!-- 弹出层 -->
			<view class="popup" v-if="showPopup">
				<view class="popup-content">
					<form>
						
						<view class="upload-image" @click="selectImage">
							<image v-if="currentGoods.goods_image" :src="shopImage(currentGoods.goods_image)"
								mode="aspectFill">
							</image>
							<view v-else class="upload-placeholder">
								<text>+</text>
							</view>
						</view>
						
						<view class="inputBox">
							<text>名称：</text>
							<input type="text" v-model="currentGoods.goods_name" placeholder="商品名称" />
						</view>
						<view class="inputBox">
							<text>规格：</text>
							<input type="text" v-model="currentGoods.norms" placeholder="规格" />
						</view>

						<view class="inputBox">
							<text>简介：</text>
							<input type="text" v-model="currentGoods.slogan" placeholder="简介" />
						</view>

						<view class="inputBox">
							<text>价格：</text>
							<input type="number" v-model="currentGoods.price" placeholder="价格" />
						</view>

						<view class="inputBox">
							<text>状态：</text>
							<radio-group @change="radiostatus">
								<label>
									<radio value="1" :checked="currentGoods.status == '1'" /> 上架
								</label>
								<label>
									<radio value="2" :checked="currentGoods.status == '2'" /> 缺货
								</label>
								<label>
									<radio value="0" :checked="currentGoods.status == '0'" /> 下架
								</label>
							</radio-group>
						</view>
						
						
						<view class="butBox">
							<view class="queren" @click="submitForm">提交</view>
							<view class="quxiao" @click="showPopup = false">取消</view>
						</view>
					</form>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navigationBarTitle: "商品管理",
				shopId: null,
				goodsList: [],
				showPopup: false,
				currentGoods: {
					goods_image: '',
					goods_name: '',
					norms: '',
					slogan: '',
					price: '',
					status: '1'
				},
				operate: ''
			};
		},

		methods: {
			radiostatus(res) {
				this.currentGoods.status = res.detail.value
			},
			shopImage(res) {
				return getApp().globalData.adminPath + res;
			},
			getStatusText(status) {
				const statusTexts = ['下架', '上架', '缺货'];
				return statusTexts[status];
			},
			loadGoodsList() {
				this.$util.request("main.Shop.goodsListByShangjia", {
					id: this.shopId
				}).then(res => {
					if (res.code === 1) {
						this.goodsList = res.data.goods;
					}
				});
			},
			addGoods() {
				this.operate = 'addDish'
				this.currentGoods = {
					goods_image: '',
					goods_name: '',
					norms: '',
					slogan: '',
					price: '',
					status: '1',
					wdsxh_shop_id: this.shopId
				};
				this.showPopup = true;
			},
			editGoods(item) {
				this.operate = 'updateDish'
				this.showPopup = true;
				this.currentGoods = {
					...item
				};
			},
			submitForm() {

				delete this.currentGoods.weigh;
				delete this.currentGoods.deletetime;
				delete this.currentGoods.score;
				if (this.operate != 'updateDish') {
					delete this.currentGoods.id;
				}
				console.log(this.currentGoods)
				// 这里区分是新增还是更新
				const method = this.operate;
				this.$util.request(`main.Shop.${method}`, {
					...this.currentGoods
				}).then(res => {
					if (res.code === 1) {
						this.showPopup = false;
						this.loadGoodsList();
					}
				});
			},
			deleteGoods(id) {
				uni.showModal({
					title: '提示',
					content: '确定要删除这个商品吗？',
					success: (res) => {
						if (res.confirm) {
							this.$util.request("main.Shop.deleteDish", {
								id
							}).then(res => {
								if (res.code === 1) {
									this.loadGoodsList();
								}
							});
						}
					}
				});
			},
			selectImage() {
				uni.chooseImage({
					count: 1,
					success: (res) => {
						this.$util.uploadFile(res.tempFilePaths[0]).then(uploadRes => {
							if (uploadRes.code === 1) {
								this.currentGoods.goods_image = uploadRes.data.url;
							}
						});
					}
				});
			}
		},
		onLoad(options) {
			this.shopId = options.id;
			this.loadGoodsList();
		}
	};
</script>

<style scoped>
	.container {
		padding: 20rpx;
		background-color: #f4f4f4;
	}

	.goods-list {
		display: flex;
		flex-direction: column;
	}

	.goods-item {
		display: flex;
		align-items: center;
		background-color: #fff;
		margin-bottom: 20rpx;
		padding: 20rpx;
		border-radius: 20rpx;
	}

	.goods-image {
		width: 150rpx;
		height: 150rpx;
		margin-right: 20rpx;
		border-radius: 10rpx;
	}

	.goods-info {
		flex: 1;
	}

	.goods-name {
		font-size: 32rpx;
		font-weight: bold;
		color: #333;
	}

	.goods-norms,
	.goods-slogan,
	.goods-price,
	.goods-status {
		font-size: 28rpx;
		color: #666;
		margin-top: 10rpx;
	}

	.inputBox{
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
	}
	.inputBox label{
		padding-right: 30rpx;
	}
	.inputBox text{
		width: 100rpx;
	}
	.inputBox input{
		flex: 1;
		border: 1rpx solid #ccc;
		padding: 10rpx;
		border-radius: 10rpx;
	}
	.inputBox .action-btn{
		margin-left: 20rpx;
	}
	.butBox{
		display: flex;
		justify-content: flex-end;
		margin-top: 20rpx;
		
	}
	.queren{
		background-color: #007aff;
		color: #fff;
		padding: 10rpx 20rpx;
		border-radius: 10rpx;
		margin-left: 20rpx;
	}
	.quxiao{
		background-color: #ccc;
		color: #333;
		padding: 10rpx 20rpx;
		border-radius: 10rpx;
	}

	.action-btn {
		margin-left: 20rpx;
		background-color: #007aff;
		color: #fff;
		padding: 10rpx 20rpx;
		border-radius: 10rpx;
	}

	.add-btn {
		width: 100%;
		background-color: #007aff;
		color: #fff;
		padding: 20rpx;
		border-radius: 10rpx;
		text-align: center;
		margin-top: 20rpx;
	}

	.popup {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.popup-content {
		background-color: #fff;
		padding: 20rpx;
		border-radius: 20rpx;
		width: 90%;
		max-height: 80%;
		overflow-y: auto;
	}

	.upload-image {
		
		width: 150rpx;
		height: 150rpx;
		border: 2rpx dashed #ccc;
		display: flex;
		align-items: center;
		justify-content: center;
		position: relative;
		margin: 20rpx auto;
	}

	.upload-image image {
		width: 100%;
		height: 100%;
		border-radius: 10rpx;
	}

	.upload-placeholder {
		width: 100%;
		height: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		font-size: 50rpx;
		color: #ccc;
	}

	.add-btn,
	.action-btn {
		padding: 10rpx 20rpx;
		background-color: #007aff;
		color: #fff;
		text-align: center;
		border-radius: 10rpx;
	}
	.deletebut{
		margin-top: 10rpx;
		background: #b41b1b;
	}
</style>