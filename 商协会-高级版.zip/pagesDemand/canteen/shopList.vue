<template>
	<view>
		<title-bar :title="navigationBarTitle"></title-bar>
		<view class="container">
			<!-- 左上角下拉菜单 -->
			<view class="top">
				<view class="dropdown">
					<view class="dropdown-button" @click="toggleDropdown">
						<image class="shop-logo" :src="selectedShop.shop_image" mode="aspectFill"></image>
						<text class="shop-name">{{ selectedShop.title }}</text>
						<text class="dropdown-icon">↓</text>
					</view>
					<view class="dropdown-menu" v-if="showDropdown">
						<view class="dropdown-item" v-for="shop in shops" :key="shop.id" @click="selectShop(shop)">
							<image class="shop-logo" :src="shop.shop_image" mode="aspectFill"></image>
							<text class="shop-name">{{ shop.title }}</text>
						</view>
					</view>
				</view>
				<!-- 店铺是否营业 -->
				<view class="business-status">
					<text>{{isBusinessOpen ? '营业中' : '休息'}} </text>
					<switch :checked="isBusinessOpen" @change="toggleBusinessStatus" />
				</view>
			</view>

			<!-- 营业额信息 -->
			<view class="revenue-box">
				<view class="revenue-item">
					<view class="revenue-value">{{ selectedShop.total_day }}</view>
					<view class="revenue-label">今日营业额</view>
				</view>
				<view class="revenue-item">
					<view class="revenue-value">{{ selectedShop.total_month }}</view>
					<view class="revenue-label">本月营业额</view>
				</view>
				<view class="revenue-item">
					<view class="revenue-value">{{ selectedShop.total_all }}</view>
					<view class="revenue-label">总营业额</view>
				</view>
			</view>

			<!-- 预留的4个菜单按钮 -->
			<view class="menu-buttons">
				<view class="menu-button" @click="navigateTo('menu1')">菜品管理</view>
				<view class="menu-button" @click="navigateTo('menu2')">店铺设置</view>
				<view class="menu-button" @click="navigateTo('menu3')">订单核销</view>
				<!-- <view class="menu-button" @click="navigateTo('menu4')">菜单4</view> -->
			</view>

			<!-- 订单状态菜单按钮 -->
			<view class="order-status-buttons">
				<view class="order-status-button" :class="{ active: currentStatus === '1' }" @click="changeStatus('1')">
					已支付</view>
				<view class="order-status-button" :class="{ active: currentStatus === '2' }" @click="changeStatus('2')">
					已接单</view>
				<view class="order-status-button" :class="{ active: currentStatus === '3' }" @click="changeStatus('3')">
					已准备就绪</view>
				<view class="order-status-button" :class="{ active: currentStatus === '4' }" @click="changeStatus('4')">
					正在配送</view>
				<view class="order-status-button" :class="{ active: currentStatus === '5' }" @click="changeStatus('5')">
					已完成</view>
			</view>

			<!-- 订单列表 -->
			<scroll-view scroll-y style="height: calc(100vh - 450rpx);">
				<view class="order-card" v-for="order in filteredOrders" :key="order.id">
					<text class="order-number">订单编号: {{ order.order_number }}</text>
					<view class="order-info">
						<text>订单类型: {{ getOrderTypeText(order.order_type) }}</text>
						<text v-if="order.order_type != '3'">预计用餐时间：{{ order.expected_time }}</text>
						<view v-if="order.order_type == '3'">
							<text>外卖信息：{{ order.address }}</text>
						</view>
						<text>商品详情:</text>
						<view v-for="detail in order.order_details" :key="detail.id" class="item-detail">
							<text>{{ detail.name }} * {{ detail.quantity }} ￥{{ detail.price }}</text>
						</view>
						<text>实际付款: {{ order.total_amount }}</text>
					</view>
					<view v-if="order.status === '1'" class="accept-order-button" @click="acceptOrder(order.order_number,'2')">立即接单</view>
					<view v-if="order.status === '2' && order.order_type != '3'" class="accept-order-button" @click="acceptOrder(order.order_number,'3')">准备就绪</view>
					<view v-if="order.status === '2' && order.order_type == '3'" class="accept-order-button" @click="acceptOrder(order.order_number,'4')">开始配送</view>
				</view>
			</scroll-view>
		</view>
	</view>
</template>
<script>
	export default {
		data() {
			return {
				navigationBarTitle: "商家管理",
				shops: [],
				selectedShop: {},
				showDropdown: false,
				isBusinessOpen: true,
				currentStatus: '1',
				orders: []
			};
		},
		computed: {
			filteredOrders() {
				return this.orders.filter(order => order.status === this.currentStatus);
			}
		},
		methods: {
			getOrderTypeText(type) {
				const orderTypes = {
					'1': '到店吃',
					'2': '到店取',
					'3': '外卖'
				};
				return orderTypes[type] || '未知类型';
			},
			toggleDropdown() {
				this.showDropdown = !this.showDropdown;
			},
			selectShop(shop) {
				this.selectedShop = shop;
				this.showDropdown = false;
				this.fetchOrders();
			},
			toggleBusinessStatus(e) {
				this.isBusinessOpen = e.detail.value;
				// updateStatusByShopId
				this.$util.request("main.Shop.updateStatusByShopId",{shop_id:this.selectedShop['id']}).then(res => {
					if (res.code === 1) {
						uni.showToast({
							title: '状态已更新',
							duration: 2000,
						})
					}
				})
			},
			changeStatus(status) {
				this.currentStatus = status;
				this.fetchOrders();
			},
			fetchShops() {
				this.$util.request("main.Shop.getShopByUserId").then(res => {
					if (res.code === 1) {
						this.shops = res.data;
						this.selectedShop = this.shops[0];
						this.isBusinessOpen = this.selectedShop['status'] === '1';
						this.fetchOrders();
					}
				}).catch(error => {
					console.error('获取店铺列表失败:', error);
				});
			},
			fetchOrders() {
				const params = {
					shop_id: this.selectedShop.id,
					type: 'all',
					page: 1,
					limit: 10
				};

				this.$util.request("main.Shop.getOrderListByShopIdPage", params).then(res => {
					if (res.code === 1) {
						this.orders = res.data;
					}
				}).catch(error => {
					console.error('获取订单列表失败:', error);
				});
			},
			acceptOrder(orderId,type) {
				var params = {
					order_number: orderId,
					status: type
				};
				this.$util.request("main.Shop.changeStatus", params).then(res => {
					if (res.code === 1) {
						uni.showToast({
							duration: 2000,
							icon: 'success',
							
						});
						this.fetchOrders();
					}
				}).catch(error => {
					console.error('接单失败:', error);
				});
				// 这里可以添加接单的逻辑
				console.log('接单:', orderId);
			},
			navigateTo(menu) {
				// 这里可以添加导航到不同菜单的逻辑
				var shopid = this.selectedShop['id']
				switch (menu){
					case 'menu1':uni.navigateTo({url:'/pagesDemand/shopDetails/goodsDetails?id='+shopid})
						break;
					case 'menu2':uni.navigateTo({url:'/pagesDemand/shopDetails/shopDetails?id='+shopid})
						break;
					case 'menu3':uni.navigateTo({url:'/pagesDemand/shopDetails/completeOrder'})
						break;
					default:
						break;
				}
			}
		},
		onShow() {
			this.fetchShops();
		}
	};
</script>
<style scoped>
	.top {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx;
		background-color: #fff;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
		border-radius: 5rpx;
		margin-bottom: 20rpx;
	}

	.container {
		padding: 20rpx;
		background-color: #f5f5f5;
		min-height: 100vh;
	}

	.dropdown {
		position: relative;
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
	}

	.dropdown-button {
		display: flex;
		align-items: center;
		cursor: pointer;
		background-color: #fff;
		padding: 10rpx 20rpx;
		border: 1rpx solid #ddd;
		border-radius: 5rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.shop-logo {
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		margin-right: 10rpx;
	}

	.shop-name {
		font-weight: bold;
		font-size: 30rpx;
		color: #333;
	}

	.dropdown-icon {
		margin-left: 5rpx;
		font-size: 30rpx;
		color: #666;
	}

	.dropdown-menu {
		position: absolute;
		top: 50rpx;
		left: 0;
		background-color: white;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
		border-radius: 5rpx;
		z-index: 1000;
		/* width: 200rpx; */
	}

	.dropdown-item {
		padding: 10rpx;
		display: flex;
		align-items: center;
		cursor: pointer;
		transition: background-color 0.3s;
	}

	.dropdown-item:hover {
		background-color: #f0f0f0;
	}

	.revenue-box {
		display: flex;
		justify-content: space-around;
		background-color: #007bff;
		color: white;
		padding: 20rpx;
		border-radius: 5rpx;
		margin-bottom: 20rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.revenue-item {
		text-align: center;
		font-size: 30rpx;
	}

	.revenue-value {
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 10rpx;
	}

	.revenue-label {
		font-size: 24rpx;
		color: #dfe6e9;
	}

	.menu-buttons {
		display: flex;
		justify-content: space-around;
		margin-bottom: 20rpx;
	}

	.menu-button {
		padding: 10rpx 20rpx;
		background-color: #007bff;
		color: white;
		border-radius: 5rpx;
		font-size: 30rpx;
		cursor: pointer;
		transition: background-color 0.3s;
	}

	.menu-button:hover {
		background-color: #0056b3;
	}

	.business-status {
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
		font-size: 30rpx;
		color: #333;
	}

	.order-status-buttons {
		display: flex;
		justify-content: space-around;
		margin-bottom: 20rpx;
	}

	.order-status-button {
		padding: 10rpx 10rpx;
		border: 1rpx solid #ccc;
		border-radius: 5rpx;
		background-color: white;
		font-size: 30rpx;
		cursor: pointer;
		transition: background-color 0.3s;
	}

	.order-status-button.active {
		background-color: #007bff;
		color: white;
	}

	.order-card {
		background-color: #fff;
		padding: 20rpx;
		border: 1rpx solid #ddd;
		border-radius: 5rpx;
		margin-bottom: 20rpx;
		box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
	}

	.order-number {
		font-weight: bold;
		font-size: 30rpx;
		margin-bottom: 10rpx;
		color: #333;
	}

	.order-info {
		display: flex;
		flex-direction: column;
		font-size: 28rpx;
		color: #555;
	}

	.item-detail {
		margin-bottom: 5rpx;
		font-size: 28rpx;
		color: #555;
	}

	.accept-order-button {
		background-color: #28a745;
		color: white;
		border: none;
		border-radius: 5rpx;
		padding: 10rpx 20rpx;
		margin-top: 10rpx;
		cursor: pointer;
		font-size: 30rpx;
		transition: background-color 0.3s;
	}

	.accept-order-button:hover {
		background-color: #218838;
	}

	/* 自定义 switch 的样式 */
	switch {
		transform: scale(0.6);
		/* 缩放大小 */
	}
</style>