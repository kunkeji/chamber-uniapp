<template>
	<view>
		<title-bar title="订单详情"></title-bar>

		<view class="container">

			<!-- 订单二维码 -->
			<view class="qrcode">
				<image :src="orderInfo.qrcode" mode="widthFix" class="qrcode-image"></image>
			</view>

			<!-- 订单信息 -->
			<view class="order-info">
				<!-- 店铺信息 -->
				<view class="shop-info">
					<image :src="shopImage(shopInfo.shop_image)" mode="aspectFill" class="shop-image"></image>
					<text class="shop-name">{{ shopInfo.title }}</text>
				</view>
				<view class="info-item">
					<text class="info-label">订单编号</text>
					<text class="info-value">{{ orderInfo.order_number }}</text>
				</view>
				<view class="info-item">
					<text class="info-label">总金额</text>
					<text class="info-value">{{ orderInfo.total_amount }} 元</text>
				</view>
				<view class="info-item">
					<text class="info-label">订单类型</text>
					<text class="info-value">{{ getOrderType(orderInfo.order_type) }}</text>
				</view>
				<template v-if="orderInfo.order_type !== '3'">
					<view class="info-item">
						<text class="info-label">期望时间</text>
						<text class="info-value">{{ orderInfo.expected_time }}</text>
					</view>
				</template>
				<template v-if="orderInfo.order_type === '3'">
					<view class="info-item">
						<text class="info-label">配送地址</text>
						<text class="info-value">{{ orderInfo.address }}</text>
					</view>
				</template>
				<view class="info-item">
					<text class="info-label">备注</text>
					<text class="info-value">{{ orderInfo.remark || '无' }}</text>
				</view>
				<view class="info-item">
					<text class="info-label">订单状态</text>
					<text class="info-value">{{ getOrderStatus(orderInfo.status) }}</text>
				</view>
				<view class="info-item">
					<text class="info-label">创建时间</text>
					<text class="info-value">{{ orderInfo.created_at }}</text>
				</view>
				<view class="info-item">
					<text class="info-label">更新时间</text>
					<text class="info-value">{{ orderInfo.updated_at }}</text>
				</view>
			</view>

			<!-- 商品信息 -->
			<view class="goods-info">
				<text class="goods-title">商品信息</text>
				<view v-for="item in orderInfo.goodsinfo" :key="item.id" class="goods-item">
					<view class="info-item">
						<text class="info-label">商品名称</text>
						<text class="info-value">{{ item.name }}</text>
					</view>
					<view class="info-item">
						<text class="info-label">数量</text>
						<text class="info-value">{{ item.quantity }}</text>
					</view>
					<view class="info-item">
						<text class="info-label">单价</text>
						<text class="info-value">{{ item.price }} 元</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				orderId: '',
				orderInfo: {},
				shopInfo: {}
			};
		},
		methods: {
			shopImage(res) {
				return getApp().globalData.adminPath + res;
			},
			getOrderType(type) {
				switch (type) {
					case '1':
						return '到店吃';
					case '2':
						return '到店取';
					case '3':
						return '外卖';
					default:
						return '未知';
				}
			},
			getOrderStatus(status) {
				switch (status) {
					case '1':
						return '待支付';
					case '2':
						return '已支付';
					case '3':
						return '已发货';
					case '4':
						return '已完成';
					case '5':
						return '已取消';
					default:
						return '未知';
				}
			},
			fetchOrderDetail() {
				this.$util.request("main.Shop.getOrderDetail", {
					id: this.orderId
				}).then(res => {
					if (res.code === 1) {
						this.orderInfo = res.data;
						this.shopInfo = res.data.shopinfo;
					} else {
						uni.showToast({
							title: '获取订单详情失败',
							icon: 'none'
						});
					}
				});
			}
		},
		onLoad(options) {
			console.log(options);
			this.orderId = options.id;
			this.fetchOrderDetail();
		}
	};
</script>

<style scoped>
	.container {
		padding: 20rpx;
		background-color: #f5f5f5;
	}

	.shop-info {
		display: flex;
		align-items: center;
		margin-bottom: 20rpx;
	}

	.shop-image {
		width: 100rpx;
		height: 100rpx;
		margin-right: 20rpx;
		border-radius: 16rpx;
	}

	.shop-name {
		font-size: 32rpx;
		font-weight: bold;
	}

	.qrcode {
		margin-bottom: 20rpx;
		width: 200rpx;
		height: 200rpx;
		margin: 40rpx auto;
		text-align: center;
	}

	.qrcode-image {
		width: 200rpx;
		height: 200rpx;
		margin-top: 10rpx;
	}

	.order-info,
	.goods-info {
		background-color: #fff;
		padding: 20rpx;
		border-radius: 16rpx;
		margin-bottom: 20rpx;
	}

	.info-item {
		display: flex;
		align-items: center;
		margin-bottom: 10rpx;
		font-size: 28rpx;
	}

	.info-label {
		flex-basis: 160rpx;
		/* 根据需要调整宽度 */
		text-align-last: justify;
		white-space: nowrap;
		color: #505050;
		margin-right: 20rpx;
		/* 防止标签换行 */
	}

	.info-value {
		flex-basis: 70%;
		/* 根据需要调整宽度 */
		text-align: left;
		white-space: nowrap;
		/* 防止值换行 */
	}

	.goods-title {
		font-weight: bold;
		margin-bottom: 10rpx;
	}

	.goods-item {
		margin-bottom: 20rpx;
	}
</style>