<template>
	<view>
		<title-bar :title="navigationBarTitle"></title-bar>
		<view class="container">
			<view class="order-type-selection">
				<!-- :class="selectedOrderType == 'dine-in'?'orderTypeclick order-type':'order-type'" -->
				<view class="order-type" :style="selectedOrderType==1?'background:#ff8000;color: #fff;':''" @click="selectOrderType('1')">
					<text>到店吃</text>
				</view>
				<view class="order-type" :style="selectedOrderType==2?'background:#ff8000;color: #fff;':''" @click="selectOrderType('2')">
					<text>到店取</text>
				</view>
				<view class="order-type" :style="selectedOrderType==3?'background:#ff8000;color: #fff;':''" @click="selectOrderType('3')">
					<text>外卖</text>
				</view>
			</view>

			<view v-if="selectedOrderType === '1' || selectedOrderType === '2'" class="time-selection">
				<view class="time-label">预计用餐时间</view>
				<picker mode="time" :value="expectedTime" @change="onTimeChange">
					<view class="time-picker">{{ expectedTime }}</view>
				</picker>
			</view>

			<view v-if="selectedOrderType === '3'" class="address-selection">
				<view class="address-label">外卖地址</view>
				<view class="address-input" @click="showAddressPopup">
					<text>{{ deliveryAddress.name }} - {{ deliveryAddress.phone }} -
						{{ deliveryAddress.address }}</text>
				</view>
			</view>

			<!-- 商品详情列表 -->
			<view class="product-list" v-if="cart.length > 0">
				<view class="product-item" v-for="item in cart" :key="item.id">
					<view class="product-name">{{ item.goods_name }}</view>
					<view class="product-quantity">×{{ item.quantity }}</view>
					<view class="product-price">¥{{ item.price }}</view>
				</view>
			</view>

			<view class="order-summary">
				<view class="summary-item">
					<text>商品总价</text>
					<text>¥{{ totalPrice }}</text>
				</view>
				<view class="summary-item">
					<text>配送费</text>
					<text>¥{{ deliveryFee }}</text>
				</view>
				<view class="summary-item">
					<text>订单总价</text>
					<text>¥{{ totalOrderPrice }}</text>
				</view>
			</view>

			<view class="order-button-box">
				<view @click="submitOrder" class="order-button">确认点餐</view>
			</view>

			<!-- 地址弹出层 -->
			<view v-if="isAddressPopupVisible" class="address-popup address-visible" @click="closeAddressPopup">
				<view class="address-content" @click.stop>
					<view class="address-header">
						<text>填写外卖地址</text>
					</view>
					<view class="address-form">
						<view class="form-group">
							<text>姓名</text>
							<input v-model="deliveryAddress.name" placeholder="请输入姓名" />
						</view>
						<view class="form-group">
							<text>性别</text>
							<radio-group @change="onGenderChange">
								
								<label class="radio-label">
									<radio value="0" :checked="deliveryAddress.gender === '0'" color="#00BFFF" />
									<text>男</text>
								</label>
								
								<label class="radio-label">
									<radio value="1" :checked="deliveryAddress.gender === '1'" color="#00BFFF" />
									<text>女</text>
								</label>
								
								<label class="radio-label">
									<radio value="2" :checked="deliveryAddress.gender === '2'" color="#00BFFF" />
									<text>超人</text>
								</label>
								
							</radio-group>
						</view>
						<view class="form-group">
							<text>电话</text>
							<input v-model="deliveryAddress.phone" placeholder="请输入电话" />
						</view>
						<view class="form-group">
							<text>具体位置</text>
							<input v-model="deliveryAddress.address" placeholder="请输入具体位置" />
						</view>
					</view>
					<view class="address-buttons">
						<view @click="saveAddress" class="save-button">保存</view>
						<view @click="closeAddressPopup" class="cancel-button">取消</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>


<script>
	export default {
		data() {
			return {
				navigationBarTitle: '下单页面',
				selectedOrderType: '',
				expectedTime: '请选择时间',
				deliveryFee: 0.00,
				isAddressPopupVisible: false,
				deliveryAddress: {
					name: '',
					gender: '0', // 默认值为男
					phone: '',
					address: ''
				},
				cart: []
			};
		},
		computed: {
			totalPrice() {
				return this.cart.reduce((total, item) => total + item.price * item.quantity, 0);
			},
			totalOrderPrice() {
				return this.totalPrice + (this.selectedOrderType === '3' ? this.deliveryFee : 0);
			}
		},
		methods: {
			selectOrderType(type) {
				this.selectedOrderType = type;
				if (type === '3') {
					this.showAddressPopup();
				}
			},
			onTimeChange(e) {
				this.expectedTime = e.detail.value;
			},
			onGenderChange(e) {
				this.deliveryAddress.gender = e.detail.value;
			},
			showAddressPopup() {
				this.isAddressPopupVisible = true;
			},
			closeAddressPopup() {
				this.isAddressPopupVisible = false;
			},
			saveAddress() {
				this.isAddressPopupVisible = false;
			},
			submitOrder() {
				if (this.selectedOrderType === '') {
					uni.showToast({
						icon: 'none',
						title: "请选择订单类型",
						duration: 2000
					});
					return;
				}

				if ((this.selectedOrderType === 'dine-in' || this.selectedOrderType === 'takeaway') && this
					.expectedTime === '请选择时间') {
					uni.showToast({
						icon: 'none',
						title: "请选择预计用餐时间",
						duration: 2000
					});
					return;
				}

				if (this.selectedOrderType === 'delivery' && (!this.deliveryAddress.name || !this.deliveryAddress.phone ||
						!this.deliveryAddress.address)) {
					uni.showToast({
						icon: 'none',
						title: "请填写完整的外卖地址",
						duration: 2000
					});
					return;
				}

				// 这里可以添加实际的提交订单逻辑
				var deliveryAddress = toString(this.deliveryAddress)
				var gender = ""
				switch (this.deliveryAddress['gender']) {
					case "0":
						gender = '先生'
						break;
					case "1":
						gender = '女士'
						break;
					case "2":
						gender = '超人'
						break;
				}
				var deliveryAddress = this.deliveryAddress['name'] + gender + " " + this.deliveryAddress['phone'] + " " +
					this.deliveryAddress['address']
				var data = {
					'shop_id': this.shop_id,
					'goods': JSON.stringify(this.cart),
					'address': deliveryAddress,
					'expected_time': this.expectedTime,
					'total_amount': this.totalOrderPrice,
					'remark': '',
					'order_type': this.selectedOrderType,
				}
				this.$util.request("main.Shop.createOrder", data).then(res => {
					if (res.code === 200) {
						uni.requestPayment({
							provider: 'wxpay', // 看需求，每个端都有各自的值，eg: 'alipay'
							timeStamp: res.data.timeStamp, // 当前时间戳（从1970年1月1日至今的秒数）
							nonceStr: res.data.nonceStr, // 随机字符串 - 也可以后端返回
							package: res.data.package, // 后端接口返回
							paySign: res.data.paySign, // 后端返回
							signType: 'MD5', // 签名的算法，默认值 ’MD5‘
							success: (result) => {
								// result成功返回内容 errMsg: "requestPayment:ok"
								if (result.errMsg == "requestPayment:ok") {
									uni.navigateTo({
										url: "/pagesDemand/canteen/canteenDetails"
									})
								}
								
								console.log('success', result)
								// 支付成功跳转结果页
							},
							fail: (err) => {
								console.log('fail', err)
								uni.showToast({
									title: '订单已生成，支付失败',
									icon: 'none',
									duration: 2000
								})
								setTimeout(() => uni.navigateBack(), 1000)
							}
						})

					} else {
						uni.showToast({
							title: "订单生成失败",
							icon: 'none',
							duration: 2000
						})
					}
				})
				uni.showToast({
					icon: 'success',
					title: "订单提交成功",
					duration: 2000
				});
			}
		},
		onLoad(options) {
			// 从 URL 参数中获取购物车数据
			if (options.cart) {
				this.cart = JSON.parse(decodeURIComponent(options.cart));
			}
			this.shop_id = options.shopid
		}
	};
</script>
<style scoped>
	.container {
		padding: 30rpx;
		background-color: #FAFAFA;
	}

	.order-type-selection {
		display: flex;
		justify-content: space-around;
		margin-bottom: 30rpx;
	}

	.order-type {
		background-color: #FFFFFF;
		border: 1rpx solid #E0E0E0;
		padding: 20rpx;
		border-radius: 10rpx;
		text-align: center;
		cursor: pointer;
		transition: background-color 0.3s, box-shadow 0.3s;
		box-shadow: 0 2rpx 5rpx rgba(0, 0, 0, 0.1);
	}

	.order-type:hover {
		background-color: #F5F5F5;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.15);
	}

	.time-selection,
	.address-selection {
		background-color: #FFFFFF;
		padding: 20rpx;
		border-radius: 10rpx;
		margin-bottom: 30rpx;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.05);
	}

	.time-label,
	.address-label {
		font-size: 32rpx;
		font-weight: 600;
		color: #333333;
		margin-bottom: 15rpx;
	}

	.time-picker,
	.address-input {
		font-size: 28rpx;
		color: #666666;
		padding: 10rpx;
		border: 1rpx solid #E0E0E0;
		border-radius: 5rpx;
		cursor: pointer;
		transition: border-color 0.3s;
		width: 100%;
	}

	.time-picker:hover,
	.address-input:hover {
		border-color: #00BFFF;
	}

	.order-summary {
		background-color: #FFFFFF;
		padding: 20rpx;
		border-radius: 10rpx;
		margin-bottom: 30rpx;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.05);
	}

	.summary-item {
		display: flex;
		justify-content: space-between;
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 15rpx;
	}

	.order-button-box {
		display: flex;
		justify-content: center;
		margin-bottom: 30rpx;
	}

	.order-button {
		background-color: #ff8000;
		color: #FFFFFF;
		padding: 15rpx 30rpx;
		border-radius: 10rpx;
		cursor: pointer;
		transition: background-color 0.3s, box-shadow 0.3s;
		font-size: 32rpx;
		text-align: center;
		box-shadow: 0 2rpx 5rpx rgba(0, 0, 0, 0.1);
	}

	.order-button:hover {
		background-color: #00A2E8;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.15);
	}

	.address-popup {
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		top: 0;
		background-color: rgba(0, 0, 0, 0.5);
		display: flex;
		justify-content: center;
		align-items: center;
		z-index: 1000;
		transition: opacity 0.3s ease;
	}

	.address-content {
		background-color: #FFFFFF;
		border-radius: 15rpx;
		padding: 30rpx;
		box-shadow: 0 -1rpx 10rpx rgba(0, 0, 0, 0.2);
		width: 90%;
		max-width: 600rpx;
		transform: translateY(100%);
		transition: transform 0.3s ease;
	}

	.address-visible .address-content {
		transform: translateY(0);
	}

	.address-header {
		font-size: 32rpx;
		font-weight: 700;
		color: #333333;
		margin-bottom: 20rpx;
	}

	.address-form {
		margin-bottom: 20rpx;
	}

	.form-group {
		margin-bottom: 15rpx;
	}

	.form-group text {
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 10rpx;
	}

	.form-group input {
		width: 100%;
		padding: 10rpx;
		border: 1rpx solid #E0E0E0;
		border-radius: 5rpx;
		font-size: 28rpx;
		color: #333333;
		transition: border-color 0.3s;
	}

	.form-group input:focus {
		border-color: #00BFFF;
	}

	.radio-label {
		display: flex;
		align-items: center;
		margin-bottom: 10rpx;
	}

	.radio-label text {
		font-size: 28rpx;
		color: #333333;
		margin-left: 10rpx;
	}

	.address-buttons {
		display: flex;
		justify-content: space-between;
	}

	.save-button,
	.cancel-button {
		background-color: #00BFFF;
		color: #FFFFFF;
		padding: 15rpx 30rpx;
		border-radius: 10rpx;
		cursor: pointer;
		transition: background-color 0.3s, box-shadow 0.3s;
		font-size: 32rpx;
		text-align: center;
		box-shadow: 0 2rpx 5rpx rgba(0, 0, 0, 0.1);
	}

	.save-button:hover,
	.cancel-button:hover {
		background-color: #00A2E8;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.15);
	}

	.orderTypeclick {
		background-color: #00A2E8;
	}

	.cancel-button {
		background-color: #FF5722;
	}

	.cancel-button:hover {
		background-color: #E64A19;
	}

	.product-list {
		margin-top: 30rpx;
		background-color: #FFFFFF;
		padding: 20rpx;
		border-radius: 10rpx;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.05);
		margin-bottom: 30rpx;
	}

	.product-item {
		display: flex;
		justify-content: space-between;
		margin-bottom: 15rpx;
	}

	.product-name,
	.product-price,
	.product-quantity {
		font-size: 28rpx;
		color: #333333;
	}

	.product-item:last-child {
		margin-bottom: 0;
	}
</style>