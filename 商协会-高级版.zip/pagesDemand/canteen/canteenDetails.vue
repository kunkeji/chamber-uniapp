<template>
	<view>
		<title-bar :title="navigationBarTitle"></title-bar>
		<view class="container">
			<view v-if="!orders.length" class="imagessBox">
				<img src="https://association.kunkeji.com/uploads/20241027/fb6b1cdc4fd133ee1826da9b41418f96.png" />
			</view>
			<view v-for="order in orders" :key="order.id" class="order-item" @click="orderDetails(order.id)">
				<view class="order-header">
					<text class="order-id">订单号: {{ order.order_number }}</text>
					<text class="order-status">{{ getOrderStatusText(order.status) }}</text>
				</view>
				<view class="order-type">
					<text>订单类型: {{ getOrderTypeText(order.order_type) }}</text>
				</view>
				<view class="order-details">
					<view v-for="item in order.order_details" :key="item.id" class="order-detail-item">
						<view class="product-name">{{ item.name }}</view>
						<view class="product-quantity">x{{ item.quantity }}</view>
						<view class="product-price">¥{{ item.price }}</view>
					</view>
				</view>
				<view class="order-summary">
					<view>订单总价: ¥{{ order.total_amount }}</view>
					<view v-if="order.order_type === '3'">配送地址: {{ order.address }}</view>
					<view v-if="order.order_type !== '3'">预计用餐时间: {{ order.expected_time }}</view>
				</view>
				<view class="order-footer">
					<text>{{ formatDate(order.created_at) }}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				navigationBarTitle: '订单列表',
				orders: [],
				refreshInterval: null
			};
		},
		created() {
			this.fetchOrderList();
			this.startRefreshInterval();
		},
		beforeDestroy() {
			this.stopRefreshInterval();
		},
		methods: {
			fetchOrderList() {
				this.$util.request("main.Shop.getOrderList")
					.then(res => {
						this.orders = res;
						console.log(res);
					})
					.catch(error => {
						console.error('获取订单列表失败:', error);
					});
			},
			getOrderStatusText(status) {
				switch (status) {
					case '-1':
						return '未支付';
					case '1':
						return '已支付';
					case '2':
						return '已接单';
					case '3':
						return '准备好了';
					case '4':
						return '正在配送';
					case '5':
						return '已完成';
					case '0':
						return '已取消';
					default:
						return status;
				}
			},
			getOrderTypeText(orderType) {
				switch (orderType) {
					case '1':
						return '到店吃';
					case '2':
						return '自取';
					case '3':
						return '外卖';
					default:
						return orderType;
				}
			},
			formatDate(dateString) {
				const date = new Date(dateString);
				return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
			},
			startRefreshInterval() {
				this.refreshInterval = setInterval(() => {
					this.fetchOrderList();
				}, 60000); // 每60秒（1分钟）刷新一次
			},
			stopRefreshInterval() {
				if (this.refreshInterval) {
					clearInterval(this.refreshInterval);
				}
			},
			orderDetails(e){
				uni.navigateTo({
					url: '/pagesDemand/canteen/orderDetails?id='+e,
				})
			}
		}
	};
</script>

<style scoped>
	.container {
		padding: 30rpx;
		background-color: #FAFAFA;
	}

	.order-item {
		background-color: #FFFFFF;
		padding: 20rpx;
		border-radius: 10rpx;
		margin-bottom: 20rpx;
		box-shadow: 0 4rpx 10rpx rgba(0, 0, 0, 0.05);
	}

	.order-header {
		display: flex;
		justify-content: space-between;
		font-size: 32rpx;
		font-weight: 600;
		color: #333333;
		margin-bottom: 15rpx;
	}

	.order-id {
		color: #333333;
	}

	.order-status {
		color: #FF5722;
	}

	.order-type {
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 15rpx;
	}

	.order-details {
		margin-bottom: 15rpx;
	}

	.order-detail-item {
		display: flex;
		justify-content: space-between;
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 10rpx;
	}

	.product-name {
		flex: 1;
		margin-right: 10rpx;
	}

	.product-quantity {
		margin-right: 10rpx;
	}

	.order-summary {
		font-size: 28rpx;
		color: #333333;
		margin-bottom: 15rpx;
	}

	.order-footer {
		font-size: 28rpx;
		color: #666666;
		text-align: right;
	}

	.imagessBox {
		position: fixed;
		top: 0%;
		right: 0%;
		left: 0%;
		bottom: 0;
		margin: auto;
		width: 430rpx;
		height: 430rpx;
	}
</style>